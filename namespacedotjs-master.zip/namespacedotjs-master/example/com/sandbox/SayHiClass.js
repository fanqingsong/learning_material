
Namespace('com.sandbox', {

	SayHiClass: function() {
		com.sandbox.Console.log('hi');
		return {};
	}

});
