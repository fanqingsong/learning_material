
Namespace('com.sandbox', {

	MyNameIsClass: function(name) {
		com.sandbox.Console.log('my name is ' + name);
		return {};
	}

});
