OperaDriver: Simple example
===========================

This is a basic example of using OperaDriver. It opens Opera, navigates to a
web page (http://www.opera.com/), selects an element and prints out the text
it contains.

To compile
----------
    javac -classpath "../../lib/*:." Example.java

To run
------
    java -classpath "../../lib/*:." Example